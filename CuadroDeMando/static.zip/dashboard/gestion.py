from dash import html, dcc
import dash_mantine_components as dmc
from dash_iconify import DashIconify


def layout_gestion():
    return html.Div(
            className="gestion-container",
            children=[

                html.H2(
                    id="titulo-gestion",
                    className="gestion-titulo"
                ),

                html.Div(
                    className="gestion-fila",
                    children=[

                        html.Div(
                            className="gestion-campo",
                            children=[
                                dmc.Select(
                                    id="auditorias-dropdown",
                                    data=[],
                                    placeholder="Seleccione una auditoría",

                                    searchable=True,
                                    clearable=True,

                                    size="md",
                                    radius="md",
                                    variant="default",
                                    w=300,
                                ),
                            ],
                        ),

                        html.Div(
                            className="gestion-campo",
                            children=[
                                dmc.Select(
                                    id="versiones-dropdown",

                                    data=[],

                                    placeholder="Seleccione una versión",

                                    searchable=True,
                                    clearable=True,

                                    disabled=True,

                                    size="md",
                                    radius="md",
                                    variant="default",

                                    w=300,

                                    styles={
                                        "input": {
                                            "borderColor": "#dbe3ec",
                                            "backgroundColor": "white",
                                            "fontSize": "15px",
                                            "fontWeight": 500,
                                        }
                                    },
                                ),
                            ],
                        ),

                    ],
                ),

                dmc.Button(
                    id="borrar-auditoria-button",
                    n_clicks=0,
                    variant="outline",
                    color="red",
                    radius="md",
                    size="md",
                    w=250,
                    disabled=True,
                    leftSection=DashIconify(
                        icon="tabler:trash",
                        width=18
                    ),
                ),

                html.Div(
                    id="mensaje-auditoria",
                    className="gestion-mensaje"
                ),

                dmc.Modal(
                    id="modal-confirmacion-auditoria",
                    opened=False,
                    centered=True,
                    withCloseButton=False,
                    title=html.Div(
                        [
                            DashIconify(
                                icon="tabler:alert-triangle",
                                width=22,
                                color="#dc2626"
                            ),
                            html.Span(
                                id="titulo-modal-auditoria",
                                style={"marginLeft": "10px"}
                            ),
                        ],
                        className="modal-header-custom",
                    ),
                    children=[
                        html.P(
                            id="texto-modal-auditoria"
                        ),

                        html.Div(
                            [
                                dmc.Button(
                                    id="cancelar-auditoria",
                                    variant="default",
                                    color="gray",
                                    radius="md",
                                ),

                                dmc.Button(
                                    id="confirmar-auditoria",
                                    color="red",
                                    radius="md",
                                    leftSection=DashIconify(
                                        icon="tabler:trash",
                                        width=16
                                    ),
                                ),
                            ],
                            className="modal-footer-custom",
                        ),
                    ],
                )

            ],
        )